package data;



public class Order {	//订单类

    private String orderNumber;			//表示订单号
    private String roomNumber;			//表示房间号
    private String customerName;		//表示用户姓名
    private String customerPhone;		//表示用户的电话

    private String orderTime;			//表示预订时间

    private String checkInTime;			//表示入住时间

    private String checkOutTime;		//表示退房时间
    private String status;				//表示订单的状态

    public Order(String orderNumber, String roomNumber, String customerName, String customerPhone, String orderTime, String checkInTime, String checkOutTime, String status) {
        this.orderNumber = orderNumber;
        this.roomNumber = roomNumber;
        this.customerName = customerName;
        this.customerPhone = customerPhone;
        this.orderTime = orderTime;
        this.checkInTime = checkInTime;
        this.checkOutTime = checkOutTime;
        this.status = status;
    }

    public Order() {
    }

    // 重写toString方法，用于输出订单信息
    @Override
    public String toString() {
        return orderNumber + "," + roomNumber + "," + customerName + "," + customerPhone + "," + orderTime + "," + checkInTime + "," + checkOutTime + "," + status;
    }

    
    
    // getter和setter方法，用于获取和设置订单信息
    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerPhone() {
        return customerPhone;
    }

    public void setCustomerPhone(String customerPhone) {
        this.customerPhone = customerPhone;
    }

    public String getOrderTime() {
        return orderTime;
    }

    public void setOrderTime(String orderTime) {
        this.orderTime = orderTime;
    }

    public String getCheckInTime() {
        return checkInTime;
    }

    public void setCheckInTime(String checkInTime) {
        this.checkInTime = checkInTime;
    }

    public String getCheckOutTime() {
        return checkOutTime;
    }

    public void setCheckOutTime(String checkOutTime) {
        this.checkOutTime = checkOutTime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
