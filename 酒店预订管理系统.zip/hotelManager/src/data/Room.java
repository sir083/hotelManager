package data;

import java.math.BigDecimal;

public class Room {		//房间类

    private String roomNumber;		//表示房间号

    private String roomType;		//表示房间类型

    private BigDecimal price;		//表示房间价格

    private String status;			//表示房间状态

    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    public String getRoomType() {
        return roomType;
    }

    public void setRoomType(String roomType) {
        this.roomType = roomType;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Room(String roomNumber, String roomType, BigDecimal price, String status) {
        this.roomNumber = roomNumber;
        this.roomType = roomType;
        this.price = price;
        this.status = status;
    }

    public Room() {
    }

    @Override
    public String toString() {
        return roomNumber + "," + roomType + "," + price + "," + status;
    }
}
