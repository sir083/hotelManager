package consts;

public class RoomConsts {
	//作为下拉列表的选项内容
    public static final String[] ROOM_TYPE = {"单人间", "双人间", "套房", "豪华间"};
}
