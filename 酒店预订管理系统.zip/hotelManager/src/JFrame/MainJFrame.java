package JFrame;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainJFrame extends JFrame {
    private JButton roomManagement, bookingManagement, checkInManagement, queryStatistics;

    public MainJFrame() {
        super("酒店管理系统");
        // 设置关闭窗口时程序退出
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // 初始化面板大小
        setSize(400, 200);
        // 设置位置居中
        setLocationRelativeTo(null);

        // 创建按钮
        roomManagement = new JButton("客房管理");
        bookingManagement = new JButton("预订管理");
        checkInManagement = new JButton("入住管理");
        queryStatistics = new JButton("查询统计");

        // 添加事件监听器
        roomManagement.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                RoomManageJFrame roomManageView = new RoomManageJFrame();
                // 在这里实现打开新面板的逻辑
            }
        });
        bookingManagement.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                OrderManageJFrame orderManageView = new OrderManageJFrame();
                // 在这里实现打开新面板的逻辑
            }
        });
        checkInManagement.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ChekInManageJFrame checkInManageView = new ChekInManageJFrame();
                // 在这里实现打开新面板的逻辑
            }
        });
        queryStatistics.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                StatisticsJFrame statisticsView = new StatisticsJFrame();
                // 在这里实现打开新面板的逻辑
            }
        });

        Container container = getContentPane();
        container.setLayout(new FlowLayout());

        // 添加按钮到面板
        container.add(roomManagement);
        container.add(bookingManagement);
        container.add(checkInManagement);
        container.add(queryStatistics);

        // 显示面板
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainJFrame());
        // 使用SwingUtilities的invokeLater方法，在事件分发线程中创建MainView对象并显示窗口
    }
}
