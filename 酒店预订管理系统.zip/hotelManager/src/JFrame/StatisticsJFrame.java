package JFrame;

import dao.OrderFileManager;
import dao.RoomFileManager;
import data.Room;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

public class StatisticsJFrame  extends JFrame {
    public StatisticsJFrame() {
        // 初始化框架
        super("酒店管理系统");
        setSize(600, 300);
        setLocationRelativeTo(null);

        // 创建按钮
        JButton queryRoomButton = new JButton("查询客房");
        JButton countAvailableRoomsButton = new JButton("统计可用客房");
        JButton analyzeOccupancyRateButton = new JButton("分析入住率");

        // 查询客房按钮事件
        queryRoomButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showQueryRoomDialog();
            }
        });

        // 统计可用客房按钮事件
        countAvailableRoomsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showCountAvailableRoomsDialog();
            }
        });

        // 分析入住率按钮事件
        analyzeOccupancyRateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showAnalyzeOccupancyRateDialog();
            }
        });

        // 布局按钮
        GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setAutoCreateGaps(true);
        layout.setAutoCreateContainerGaps(true);

        layout.setHorizontalGroup(
                layout.createSequentialGroup()		// 创建一个顺序布局组
                        .addComponent(queryRoomButton)// 添加查询房间按钮到布局组中
                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)    // 添加一个与组件相关的首选间隙
                        .addComponent(countAvailableRoomsButton)
                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(analyzeOccupancyRateButton)
        );

        layout.setVerticalGroup(  // 创建一个并行组，用于容纳多个组件
                layout.createParallelGroup()
                        .addComponent(queryRoomButton)
                        .addComponent(countAvailableRoomsButton)
                        .addComponent(analyzeOccupancyRateButton)
        );

        // 显示框架
        setVisible(true);
    }

    private void showQueryRoomDialog() {
        Object[][] rooms = new Object[0][];
        List<Room> roomList = RoomFileManager.getAllRooms();
        if (roomList != null) {
            rooms = new Object[roomList.size()][4];
            for (int i = 0; i < roomList.size(); i++) {
                rooms[i][0] = roomList.get(i).getRoomNumber();
                rooms[i][1] = roomList.get(i).getRoomType();
                rooms[i][2] = roomList.get(i).getPrice();
                rooms[i][3] = roomList.get(i).getStatus();
            }
        }
        // 实现客房查询对话框
        JTable table = new JTable(rooms, new Object[]{"房号", "客房类型", "价格", "状态"});

        JOptionPane.showMessageDialog(this, new JScrollPane(table), "客房查询", JOptionPane.PLAIN_MESSAGE);
    }

    private void showCountAvailableRoomsDialog() {
        List<Room> roomList = RoomFileManager.getByStatus("空闲");
        BigDecimal totalPrice = BigDecimal.ZERO;
        if (roomList != null) {
            int count = 0;
            for (Room room : roomList) {
                if (room.getStatus().equals("空闲")) {
                    count++;
                    totalPrice = totalPrice.add(room.getPrice());
                }
            }
            // 实现统计可用客房对话框
            String message = "当前可用客房数量：" + count + "\n客房总价格：" + totalPrice + "元";
            JOptionPane.showMessageDialog(this, message, "统计可用客房", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "没有空闲客房", "统计可用客房", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void showAnalyzeOccupancyRateDialog() {
        // 通过订单统计入住率
        AtomicReference<Integer> totalOrders = new AtomicReference<>(0);
        AtomicReference<Integer> effectOrders = new AtomicReference<>(0);
        OrderFileManager.getAllOrders().forEach(order -> {
            totalOrders.getAndSet(totalOrders.get() + 1);
            if (order.getStatus().equals("已入住") || order.getStatus().equals("已离店")) {
                effectOrders.getAndSet(effectOrders.get() + 1);
            }
        });
        // 实现分析入住率对话框
        if (totalOrders.get() == 0) {
            JOptionPane.showMessageDialog(this, "没有订单", "分析入住率", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String message = "入住客人数：" + totalOrders.get() + "\n预定人数：" + effectOrders.get() + "\n入住率：" + effectOrders.get() * 100 / totalOrders.get() + "%";
        JOptionPane.showMessageDialog(this, message, "分析入住率", JOptionPane.INFORMATION_MESSAGE);
    }
}
