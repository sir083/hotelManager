package JFrame;

import consts.RoomConsts;
import dao.RoomFileManager;
import data.Room;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;

public class RoomManageJFrame extends JFrame {
    private JButton addRoom, searchRoom;
    private JTable roomTable;
    private DefaultTableModel tableModel;

    private class ButtonRenderer extends DefaultTableCellRenderer {
        private JButton editButton;
        private JButton deleteButton;

        public ButtonRenderer() {
            editButton = new JButton("编辑");
            deleteButton = new JButton("删除");
            setOpaque(true); // 必须为true，否则按钮可能透明不可见
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            if (column == 4) { // 如果是最后一列
                JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
                panel.add(editButton);
                panel.add(deleteButton);
                return panel;
            } else {
                return super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            }
        }
    }

    // 创建自定义的单元格编辑器
    private class EditDeleteCellEditor extends AbstractCellEditor implements TableCellEditor {
        private JButton editButton;
        private JButton deleteButton;
        private JPanel editorPanel;
        private JTable table;


        public EditDeleteCellEditor(JTable table) {
            this.table = table;
            editButton = new JButton("编辑");
            deleteButton = new JButton("删除");

            editButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    int viewRow = table.convertRowIndexToView(table.getEditingRow());
                    int modelRow = table.convertRowIndexToModel(viewRow);
                    Object rowData = table.getValueAt(modelRow, 0); // 获取第一列（假设是房间号）的数据
                    AddRoomDialog dialog = new AddRoomDialog(RoomManageJFrame.this, new Room(table.getValueAt(modelRow, 0).toString(), table.getValueAt(modelRow, 1).toString(), new BigDecimal(table.getValueAt(modelRow, 2).toString()), table.getValueAt(modelRow, 3).toString()), true);
                    dialog.setVisible(true);
                    // 在这里实现编辑按钮的逻辑
                    fireEditingStopped(); // 停止编辑状态
                }
            });

            deleteButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    int viewRow = table.convertRowIndexToView(table.getEditingRow());
                    int modelRow = table.convertRowIndexToModel(viewRow);
                    RoomFileManager.deleteRoom(table.getValueAt(modelRow, 0).toString());
                    RoomManageJFrame.this.refreshTableData();
                    // 在这里实现删除按钮的逻辑
                    fireEditingStopped(); // 停止编辑状态
                }
            });

            editorPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
            editorPanel.add(editButton);
            editorPanel.add(deleteButton);
        }

        @Override
        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
            return editorPanel; // 直接返回包含按钮的面板
        }

        @Override
        public Object getCellEditorValue() {
            return null; // 这里可以返回一个值，但在这个场景下我们主要关注按钮的点击事件
        }
    }

    public RoomManageJFrame() {
        super("酒店管理系统");
        setSize(700, 400);
        setLocationRelativeTo(null);

        // 初始化表格模型
        String[] columnNames = {"房间号", "类型", "价格", "状态", "操作"};
        tableModel = new DefaultTableModel(columnNames, 0);

        // 创建表格
        roomTable = new JTable(tableModel);
        roomTable.setRowHeight(50);
        // 创建表格滚动面板
        JScrollPane scrollPane = new JScrollPane(roomTable);

        // 确保JScrollPane能够正确显示所有内容
        scrollPane.getViewport().setBackground(Color.WHITE); // 可选，设置滚动视图背景色
        scrollPane.setPreferredSize(new Dimension(700, 300)); // 设置滚动面板的首选大小，以适应内容

        // 创建按钮
        addRoom = new JButton("新增客房");
        searchRoom = new JButton("查询客房");

        // 添加事件监听器
        addRoom.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new AddRoomDialog(RoomManageJFrame.this, null, false).setVisible(true);
            }
        });
        searchRoom.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                refreshTableData();
                // 在这里实现查询客房的逻辑
            }
        });

        // 创建最后一列的编辑和删除按钮
        roomTable.getColumn("操作").setCellEditor(new EditDeleteCellEditor(roomTable));
        roomTable.getColumn("操作").setCellRenderer(new ButtonRenderer());

        // 创建容器并设置布局
        Container container = getContentPane();
        container.setLayout(new BorderLayout());

        // 添加按钮到面板
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(addRoom);
        buttonPanel.add(searchRoom);
        container.add(buttonPanel, BorderLayout.NORTH);

        // 添加表格到面板
        container.add(scrollPane, BorderLayout.CENTER);

        // 显示面板
        setVisible(true);
//        refreshTableData();
    }

    public void refreshTableData() {
        // 这里添加你的逻辑来重新查询数据库或更新数据模型
        // 假设你有一个方法loadData()可以从数据库加载数据并更新到表格
        loadData();
        // 或者如果你的数据模型是DefaultTableModel，可以直接调用fireTableDataChanged()
        ((DefaultTableModel) roomTable.getModel()).fireTableDataChanged();
    }

    private void loadData() {
        tableModel.setRowCount(0);
        RoomFileManager.getAllRooms().forEach(room -> {
            tableModel.addRow(new Object[]{room.getRoomNumber(), room.getRoomType(), room.getPrice(), room.getStatus(), null});
        });
        roomTable.setModel(tableModel);
    }

    class AddRoomDialog extends JDialog {
        private JTextField roomNumberField;
        private JComboBox<String> roomTypeComboBox;
        private JTextField priceField;
        private JButton confirmButton;
        private boolean isEditMode; // 标记是否为编辑模式

        public AddRoomDialog(JFrame parent, Room room, boolean isEditMode) {
            super(parent, "新增房间", true); // 第三个参数为true表示模态对话框
            setSize(300, 200);
            setLocationRelativeTo(parent); // 居中显示

            this.isEditMode = isEditMode;

            // 初始化组件
            JLabel roomNumberLabel = new JLabel("房号:");
            roomNumberField = new JTextField(10);


            JLabel roomTypeLabel = new JLabel("类型:");
            roomTypeComboBox = new JComboBox<>(RoomConsts.ROOM_TYPE);


            JLabel priceLabel = new JLabel("价格:");
            priceField = new JTextField(10);

            if (isEditMode) {
                setTitle("编辑房间");
                roomNumberField.setText(String.valueOf(room.getRoomNumber()));
                roomTypeComboBox.setSelectedItem(room.getRoomType());
                priceField.setText(String.valueOf(room.getPrice()));
            }

            confirmButton = new JButton("确认保存");
            confirmButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String roomNumber = roomNumberField.getText();
                    String roomType = (String) roomTypeComboBox.getSelectedItem();
                    String priceStr = priceField.getText();

                    // 这里可以添加验证逻辑，确保输入有效
                    try {
                        // 保存数据到你的数据结构或数据库
                        if (isEditMode) {
                            Room updatedRoom = new Room(roomNumber, roomType, new BigDecimal(priceStr), room.getStatus());
                            RoomFileManager.updateRoom(updatedRoom);
                        } else {
                            Room newRoom = new Room(roomNumber, roomType, new BigDecimal(priceStr), "空闲");
                            RoomFileManager.addRoom(newRoom);
                        }
                        JOptionPane.showMessageDialog(null, "房间信息已保存！");
                        dispose(); // 关闭对话框
                        // 添加这一行来调用刷新方法
                        RoomManageJFrame.this.refreshTableData();
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(null, "价格必须是数字！");
                    }
                }
            });

            // 布局
            JPanel panel = new JPanel(new GridLayout(4, 2));
            panel.add(roomNumberLabel);
            panel.add(roomNumberField);
            panel.add(roomTypeLabel);
            panel.add(roomTypeComboBox);
            panel.add(priceLabel);
            panel.add(priceField);
            panel.add(new JLabel()); // 填充空白
            panel.add(confirmButton);

            add(panel);
        }
    }
}


