package JFrame;

import consts.RoomConsts;
import dao.OrderFileManager;
import dao.RoomFileManager;
import data.Order;
import data.Room;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellEditor;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class ChekInManageJFrame extends JFrame {

    private DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private JTable roomTable;
    private DefaultTableModel tableModel;

    private class ButtonRenderer extends DefaultTableCellRenderer {
        private JButton editButton;
        private JButton deleteButton;

        public ButtonRenderer() {
            editButton = new JButton("入住");
            deleteButton = new JButton("离店");
            setOpaque(true); // 必须为true，否则按钮可能透明不可见
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            if (column == table.getColumnCount() - 1) { // 如果是最后一列
                JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
                panel.add(editButton);
                panel.add(deleteButton);
                return panel;
            } else {
                return super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            }
        }
    }

    // 创建自定义的单元格编辑器
    private class EditDeleteCellEditor extends AbstractCellEditor implements TableCellEditor {
        private JButton editButton;
        private JButton deleteButton;
        private JPanel editorPanel;
        private JTable table;


        public EditDeleteCellEditor(JTable table) {
            this.table = table;
            editButton = new JButton("入住");
            deleteButton = new JButton("离店");

            editButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    int viewRow = table.convertRowIndexToView(table.getEditingRow());
                    int modelRow = table.convertRowIndexToModel(viewRow);
                    Order order = OrderFileManager.getById(table.getValueAt(modelRow, 0).toString());
                    if (!order.getStatus().equals("已预订")) {
                        JOptionPane.showMessageDialog(ChekInManageJFrame.this, "入住失败");
                    }
                    order.setCheckInTime(formatter.format(LocalDateTime.now()));
                    order.setStatus("已入住");
                    OrderFileManager.updateOrder(order);
                    JOptionPane.showMessageDialog(ChekInManageJFrame.this, "入住成功");
                    ChekInManageJFrame.this.refreshTableData();
                    // 在这里实现编辑按钮的逻辑
                    fireEditingStopped(); // 停止编辑状态
                }
            });

            deleteButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    int viewRow = table.convertRowIndexToView(table.getEditingRow());
                    int modelRow = table.convertRowIndexToModel(viewRow);
                    Order order = OrderFileManager.getById(table.getValueAt(modelRow, 0).toString());
                    if (!order.getStatus().equals("已入住")) {
                        JOptionPane.showMessageDialog(ChekInManageJFrame.this, "未入住不可离店");
                        return;
                    }
                    order.setCheckOutTime(formatter.format(LocalDateTime.now()));
                    order.setStatus("已离店");
                    OrderFileManager.updateOrder(order);
                    Room room = RoomFileManager.getById(order.getRoomNumber());
                    room.setStatus("空闲");
                    RoomFileManager.updateRoom(room);
                    JOptionPane.showMessageDialog(ChekInManageJFrame.this, "离店成功");
                    ChekInManageJFrame.this.refreshTableData();
                    // 在这里实现删除按钮的逻辑
                    fireEditingStopped(); // 停止编辑状态
                }
            });

            editorPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
            editorPanel.add(editButton);
            editorPanel.add(deleteButton);
        }

        @Override
        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
            return editorPanel; // 直接返回包含按钮的面板
        }

        @Override
        public Object getCellEditorValue() {
            return null; // 这里可以返回一个值，但在这个场景下我们主要关注按钮的点击事件
        }
    }

    public ChekInManageJFrame() {
        super("酒店管理系统");
        setSize(1100, 400);
        setLocationRelativeTo(null);

        // 初始化表格模型
        String[] columnNames = {"订单号","客户姓名", "客户手机号", "房间号", "入住状态", "入住时间", "离店时间", "操作"};
        tableModel = new DefaultTableModel(columnNames, 0);

        // 创建表格
        roomTable = new JTable(tableModel);
        roomTable.setRowHeight(50);
        // 创建表格滚动面板
        JScrollPane scrollPane = new JScrollPane(roomTable);

        // 确保JScrollPane能够正确显示所有内容
        scrollPane.getViewport().setBackground(Color.WHITE); // 可选，设置滚动视图背景色
        scrollPane.setPreferredSize(new Dimension(900, 300)); // 设置滚动面板的首选大小，以适应内容

        // 创建最后一列的编辑和删除按钮
        roomTable.getColumn("操作").setCellEditor(new EditDeleteCellEditor(roomTable));
        roomTable.getColumn("操作").setCellRenderer(new ButtonRenderer());

        // 创建容器并设置布局
        Container container = getContentPane();
        container.setLayout(new BorderLayout());

        // 添加按钮到面板
        JPanel buttonPanel = new JPanel();
//        container.add(buttonPanel, BorderLayout.NORTH);

        // 添加表格到面板
        container.add(scrollPane, BorderLayout.CENTER);

        // 显示面板
        setVisible(true);
        refreshTableData();
    }

    public void refreshTableData() {
        // 这里添加你的逻辑来重新查询数据库或更新数据模型
        // 假设你有一个方法loadData()可以从数据库加载数据并更新到表格
        loadData();
        // 或者如果你的数据模型是DefaultTableModel，可以直接调用fireTableDataChanged()
        ((DefaultTableModel) roomTable.getModel()).fireTableDataChanged();
    }

    private void loadData() {
        tableModel.setRowCount(0);
        for (Order order : OrderFileManager.getByStatus("已预订")) {
            Object[] rowData = {order.getOrderNumber(), order.getCustomerName(), order.getCustomerPhone(), order.getRoomNumber(), order.getStatus(), order.getCheckInTime(), order.getCheckOutTime()};
            tableModel.addRow(rowData);
        }
        for (Order order : OrderFileManager.getByStatus("已入住")) {
            Object[] rowData = {order.getOrderNumber(), order.getCustomerName(), order.getCustomerPhone(), order.getRoomNumber(), order.getStatus(), order.getCheckInTime(), order.getCheckOutTime()};
            tableModel.addRow(rowData);
        }
        for (Order order : OrderFileManager.getByStatus("已离店")) {
            Object[] rowData = {order.getOrderNumber(), order.getCustomerName(), order.getCustomerPhone(), order.getRoomNumber(), order.getStatus(), order.getCheckInTime(), order.getCheckOutTime()};
            tableModel.addRow(rowData);
        }
        roomTable.setModel(tableModel);
    }

    class AddRoomDialog extends JDialog {
        private JTextField roomNumberField;
        private JComboBox<String> roomTypeComboBox;
        private JTextField priceField;
        private JButton confirmButton;
        private boolean isEditMode; // 标记是否为编辑模式

        public AddRoomDialog(JFrame parent, Room room, boolean isEditMode) {
            super(parent, "新增房间", true); // 第三个参数为true表示模态对话框
            setSize(300, 200);
            setLocationRelativeTo(parent); // 居中显示

            this.isEditMode = isEditMode;
            if (isEditMode) {
                setTitle("编辑房间");
            }
            // 初始化组件
            JLabel roomNumberLabel = new JLabel("房号:");
            roomNumberField = new JTextField(10);
            roomNumberField.setText(String.valueOf(room.getRoomNumber()));

            JLabel roomTypeLabel = new JLabel("类型:");
            roomTypeComboBox = new JComboBox<>(RoomConsts.ROOM_TYPE);
            roomTypeComboBox.setSelectedItem(room.getRoomType());

            JLabel priceLabel = new JLabel("价格:");
            priceField = new JTextField(10);
            priceField.setText(String.valueOf(room.getPrice()));

            confirmButton = new JButton("确认保存");
            confirmButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String roomNumber = roomNumberField.getText();
                    String roomType = (String) roomTypeComboBox.getSelectedItem();
                    String priceStr = priceField.getText();

                    // 这里可以添加验证逻辑，确保输入有效
                    try {
                        double price = Double.parseDouble(priceStr);
                        // 保存数据到你的数据结构或数据库
                        JOptionPane.showMessageDialog(null, "房间信息已保存！");
                        dispose(); // 关闭对话框
                        // 添加这一行来调用HotelManagementSystem的刷新方法
                        ChekInManageJFrame.this.refreshTableData();
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(null, "价格必须是数字！");
                    }
                }
            });

            // 布局
            JPanel panel = new JPanel(new GridLayout(4, 2));
            panel.add(roomNumberLabel);
            panel.add(roomNumberField);
            panel.add(roomTypeLabel);
            panel.add(roomTypeComboBox);
            panel.add(priceLabel);
            panel.add(priceField);
            panel.add(new JLabel()); // 填充空白
            panel.add(confirmButton);

            add(panel);
        }
    }
}


