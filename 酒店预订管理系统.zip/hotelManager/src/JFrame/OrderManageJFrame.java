package JFrame;

import consts.RoomConsts;
import dao.OrderFileManager;
import dao.RoomFileManager;
import data.Order;
import data.Room;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

public class OrderManageJFrame extends JFrame {
    private JTable table;
    private DefaultTableModel tableModel;

    public OrderManageJFrame() {
        // 初始化框架
        super("酒店管理系统");
        setSize(600, 400);
        setLocationRelativeTo(null);

        // 创建表格模型并添加列
        String[] columnNames = {"订单号", "客户姓名", "客户手机号", "预定房号", "预定时间", "状态", "操作"};
        tableModel = new DefaultTableModel(columnNames, 0);

        // 添加一些示例数据（实际应用中应从数据库获取）

        // 创建表格组件
        table = new JTable(tableModel);
        table.setRowHeight(30);
        JScrollPane scrollPane = new JScrollPane(table);

        // 创建按钮
        JButton reserveButton = new JButton("预定");
        reserveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                OrderDialog orderDialog = new OrderDialog(OrderManageJFrame.this);
                orderDialog.setVisible(true);
            }
        });
        JButton searchButton = new JButton("查询");
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                refreshTableData();
                // 在这里实现查询客房的逻辑
            }
        });

        // 创建按钮的布局
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.add(reserveButton);
        buttonPanel.add(searchButton);

        // 添加组件到框架
        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.NORTH);

        // 创建取消按钮的单元格渲染器和编辑器
        table.getColumn("操作").setCellEditor(new OrderManageJFrame.EditDeleteCellEditor(table));
        table.getColumn("操作").setCellRenderer(new OrderManageJFrame.ButtonRenderer());

        // 显示框架
        setVisible(true);
    }

    public void refreshTableData() {
        // 这里添加你的逻辑来重新查询数据库或更新数据模型
        // 假设你有一个方法loadData()可以从数据库加载数据并更新到表格
        loadData();
        // 或者如果你的数据模型是DefaultTableModel，可以直接调用fireTableDataChanged()
        ((DefaultTableModel) table.getModel()).fireTableDataChanged();
    }

    private void loadData() {
        tableModel.setRowCount(0);
        OrderFileManager.getByStatus("已预订").forEach(order -> {
            tableModel.addRow(new Object[]{
                    order.getOrderNumber(),
                    order.getCustomerName(),
                    order.getCustomerPhone(),
                    order.getRoomNumber(),
                    order.getOrderTime(),
                    order.getStatus()
            });
        });
        OrderFileManager.getByStatus("已入住").forEach(order -> {
            tableModel.addRow(new Object[]{
                    order.getOrderNumber(),
                    order.getCustomerName(),
                    order.getCustomerPhone(),
                    order.getRoomNumber(),
                    order.getOrderTime(),
                    order.getStatus()
            });
        });
        OrderFileManager.getByStatus("已离店").forEach(order -> {
            tableModel.addRow(new Object[]{
                    order.getOrderNumber(),
                    order.getCustomerName(),
                    order.getCustomerPhone(),
                    order.getRoomNumber(),
                    order.getOrderTime(),
                    order.getStatus()
            });
        });
        OrderFileManager.getByStatus("已取消").forEach(order -> {
            tableModel.addRow(new Object[]{
                    order.getOrderNumber(),
                    order.getCustomerName(),
                    order.getCustomerPhone(),
                    order.getRoomNumber(),
                    order.getOrderTime(),
                    order.getStatus()
            });
        });
        table.setModel(tableModel);
    }

    private class ButtonRenderer extends DefaultTableCellRenderer {
        private JButton deleteButton;

        public ButtonRenderer() {
            deleteButton = new JButton("取消预订");
            setOpaque(true); // 必须为true，否则按钮可能透明不可见
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            if (column == table.getColumnCount() - 1) { // 如果是最后一列
                JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
                panel.add(deleteButton);
                return panel;
            } else {
                return super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            }
        }
    }

    // 创建自定义的单元格编辑器
    private class EditDeleteCellEditor extends AbstractCellEditor implements TableCellEditor {
        private JButton deleteButton;
        private JPanel editorPanel;
        private JTable table;


        public EditDeleteCellEditor(JTable table) {
            this.table = table;
            deleteButton = new JButton("取消预订");

            deleteButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    int viewRow = table.convertRowIndexToView(table.getEditingRow());
                    int modelRow = table.convertRowIndexToModel(viewRow);
                    Object rowData = table.getValueAt(modelRow, 0); // 获取第一列（假设是房间号）的数据
                    Order order = OrderFileManager.getById(table.getValueAt(modelRow, 0).toString());
                    order.setStatus("已取消");
                    String roomNumber = order.getRoomNumber();
                    Room room = RoomFileManager.getById(roomNumber);
                    room.setStatus("空闲");
                    RoomFileManager.updateRoom(room);
                    OrderFileManager.updateOrder(order);
                    OrderManageJFrame.this.refreshTableData();
                    // 在这里实现删除按钮的逻辑
                    fireEditingStopped(); // 停止编辑状态
                }
            });

            editorPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
            editorPanel.add(deleteButton);
        }

        @Override
        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
            return editorPanel; // 直接返回包含按钮的面板
        }

        @Override
        public Object getCellEditorValue() {
            return null; // 这里可以返回一个值，但在这个场景下我们主要关注按钮的点击事件
        }
    }

    class OrderDialog extends JDialog {
        private JTextField dateField;
        private JTextField customerNameField;
        private JTextField customerPhoneField;
        private JComboBox<String> roomTypeComboBox;
        private JTextField quantityField;
        private JButton saveButton;

        public OrderDialog(JFrame parent) {
            super(parent, "预定房间", true);
            setSize(400, 200);
            setLocationRelativeTo(parent);

            JLabel dateLabel = new JLabel("预定日期:");
            dateField = new JTextField(10);

            // 初始化组件
            JLabel customerNameLabel = new JLabel("姓名:");
            customerNameField = new JTextField(10);

            JLabel customerPhoneLabel = new JLabel("手机号:");
            customerPhoneField = new JTextField(10);

            JLabel roomTypeLabel = new JLabel("客房类型:");
            roomTypeComboBox = new JComboBox<>(RoomConsts.ROOM_TYPE);

            JLabel quantityLabel = new JLabel("客房数量:");
            quantityField = new JTextField(5);

            saveButton = new JButton("保存");
            saveButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String customerName = customerNameField.getText();
                    String customerPhone = customerPhoneField.getText();
                    String dateString = dateField.getText();
                    String roomType = (String) roomTypeComboBox.getSelectedItem();
                    String quantityStr = quantityField.getText();
                    try {
                        // 简单的验证输入
                        int quantity = Integer.parseInt(quantityStr);
                        List<Room> roomList = RoomFileManager.getByStatusAndType("空闲", roomType);
                        if (roomList.size() < quantity) {
                            JOptionPane.showMessageDialog(null, "没有足够的空闲客房！");
                            return;
                        }
                        for (int i = 0; i < quantity; i++) {
                            Room room = roomList.get(i);
                            room.setStatus("占用");
                            RoomFileManager.updateRoom(room);
                            Order order = new Order(UUID.randomUUID().toString(), room.getRoomNumber(), customerName, customerPhone, dateString, "", "", "已预订");
                            OrderFileManager.addOrder(order);
                        }
                        OrderManageJFrame.this.refreshTableData();
                        dispose(); // 关闭对话框
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(null, "客房数量必须是整数！");
                    }
                }
            });

            // 布局
            JPanel panel = new JPanel(new GridLayout(6, 2));
            panel.add(customerNameLabel);
            panel.add(customerNameField);
            panel.add(customerPhoneLabel);
            panel.add(customerPhoneField);
            panel.add(dateLabel);
            panel.add(dateField);
            panel.add(roomTypeLabel);
            panel.add(roomTypeComboBox);
            panel.add(quantityLabel);
            panel.add(quantityField);
            panel.add(new JLabel()); // 填充空白
            panel.add(saveButton);

            add(panel);
        }
    }
}
