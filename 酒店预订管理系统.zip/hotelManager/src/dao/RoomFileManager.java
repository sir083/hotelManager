package dao;

import java.io.*;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;

import data.Room;

public class RoomFileManager {
    private static final String filePath = "rooms.txt"; // 文件路径

    static {
        // 类初始化块，检查并创建文件
        File file = new File(filePath);
        if (!file.exists()) {
            try {
                Files.createFile(file.toPath()); // 创建文件
            } catch (IOException e) {
                throw new RuntimeException("Failed to create the file", e);
            }
        }
    }

    // 读取所有房间信息
    public static List<Room> getAllRooms() {
        List<Room> rooms = new ArrayList<>();
        try {
            Files.lines(Paths.get(filePath))
                    .map(line -> line.split(","))
                    .forEach(parts -> {
                        if (parts.length == 4) {
                            try {
                                rooms.add(new Room(parts[0], parts[1], new BigDecimal(parts[2]), parts[3]));
                            } catch (NumberFormatException e) {
                                System.err.println("Error parsing price for a room: " + parts[0]);
                            }
                        }
                    });
        } catch (IOException e) {
            e.printStackTrace();
        }
        return rooms;
    }

    public static Room getById(String roomNumber) {
        List<Room> rooms = getAllRooms();
        for (Room room : rooms) {
            if (room.getRoomNumber().equals(roomNumber)) {
                return room;
            }
        }
        return null;
    }

    public static List<Room> getByStatus(String status) {
        List<Room> rooms = getAllRooms();
        List<Room> filteredRooms = new ArrayList<>();
        for (Room room : rooms) {
            if (room.getStatus().equals(status)) {
                filteredRooms.add(room);
            }
        }
        return filteredRooms;
    }

    //根据状态和类型搜索
    public static List<Room> getByStatusAndType(String status, String type) {
        List<Room> rooms = getAllRooms();
        List<Room> filteredRooms = new ArrayList<>();
        for (Room room : rooms) {
            if (room.getStatus().equals(status) && room.getRoomType().equals(type)) {
                filteredRooms.add(room);
            }
        }
        return filteredRooms;
    }

    //根据类型搜索
    public static List<Room> getByType(String type) {
        List<Room> rooms = getAllRooms();
        List<Room> filteredRooms = new ArrayList<>();
        for (Room room : rooms) {
            if (room.getRoomType().equals(type)) {
                filteredRooms.add(room);
            }
        }
        return filteredRooms;
    }

    // 添加房间
    public static void addRoom(Room room) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath, true))) {
            writer.write(room.toString());
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // 删除房间（根据房间号）
    public static void deleteRoom(String roomNumber) {
        List<String> lines = new ArrayList<>();
        try {
            lines = Files.lines(Paths.get(filePath))
                    .filter(line -> !line.startsWith(roomNumber))
                    .collect(Collectors.toList());
            Files.write(Paths.get(filePath), lines);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // 更新房间信息（根据房间号）
    public static boolean updateRoom(Room updatedRoom) {
        List<String> lines = new ArrayList<>();
        AtomicBoolean updated = new AtomicBoolean(false);
        try {
            lines = Files.lines(Paths.get(filePath))
                    .map(line -> {
                        if (line.startsWith(updatedRoom.getRoomNumber())) {
                            updated.set(true);
                            return updatedRoom.toString();
                        }
                        return line;
                    })
                    .collect(Collectors.toList());
            Files.write(Paths.get(filePath), lines);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return updated.get();
    }
}
