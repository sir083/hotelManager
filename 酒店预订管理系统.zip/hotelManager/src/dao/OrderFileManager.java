package dao;


import java.io.*;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;

import data.Order;

public class OrderFileManager {
    private static final String filePath = "orders.txt"; // 文件路径

    
    static {      //设置静态代码
        File file = new File(filePath);
        if (!file.exists()) {
            try {
                Files.createFile(file.toPath()); // 创建文件
            } catch (IOException e) {
                throw new RuntimeException("文件创建失败", e);
            }
        }
    }

    // 读取所有订单信息
    public static List<Order> getAllOrders() {
        List<Order> orders = new ArrayList<>();
        try {
            Files.lines(Paths.get(filePath))
            // 从文件中读取每一行数据
            .map(line -> line.split(",")) 			// 将每一行数据按照逗号分隔，得到一个字符串数组
            .forEach(parts -> { 					// 遍历每个字符串数组
                if (parts.length == 8) {			 // 如果数组长度为8，说明该行数据是一个完整的订单信息
                    try {
                        orders.add(new Order(		 // 创建一个新的订单对象，并将其添加到订单列表中
                                        parts[0],
                                        parts[1],
                                        parts[2],
                                        parts[3],
                                        parts[4],
                                        parts[5],
                                        parts[6],
                                        parts[7]
                                ));
                            } catch (Exception e) {
                                System.err.println("解析订单错误： " + parts[0]);
                            }
                        }
                    });
        } catch (IOException e) {
            e.printStackTrace();
        }
        return orders;// 返回订单列表
    }

    public static Order getById(String orderNumber) {
        List<Order> orders = getAllOrders();
        for (Order order : orders) {
            if (order.getOrderNumber().equals(orderNumber)) {
                return order;
            }
        }
        return null;
    }

    //根据状态查找
    public static List<Order> getByStatus(String status) {
        List<Order> orders = getAllOrders();
        List<Order> filteredOrders = new ArrayList<>();
        for (Order order : orders) {
            if (order.getStatus().equals(status)) {
                filteredOrders.add(order);
            }
        }
        return filteredOrders;
    }

    // 添加订单
    public static void addOrder(Order order) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath, true))) {
            writer.write(order.toString());
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // 更新订单（根据订单号）
    public static boolean updateOrder(Order updatedOrder) {
        List<String> lines = new ArrayList<>();
        AtomicBoolean updated = new AtomicBoolean(false);
        try {
            lines = Files.lines(Paths.get(filePath))
                    .map(line -> {
                        if (line.startsWith(updatedOrder.getOrderNumber())) {
                            updated.set(true);
                            return updatedOrder.toString();
                        }
                        return line;
                    })
                    .collect(Collectors.toList());
            Files.write(Paths.get(filePath), lines);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return updated.get();
    }

    // 删除订单（根据订单号）
    public static void deleteOrder(String orderNumber) {
        List<String> lines = new ArrayList<>();
        try {
            lines = Files.lines(Paths.get(filePath))
                    .filter(line -> !line.startsWith(orderNumber))
                    .collect(Collectors.toList());
            Files.write(Paths.get(filePath), lines);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
